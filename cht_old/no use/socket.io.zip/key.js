module.exports={
  host     : '121.169.212.220',
  user     : 'itk',
  password : 'q34tq34t'
}